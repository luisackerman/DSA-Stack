from flask import Flask, render_template, request

app = Flask(__name__)

# Code for the linked list-based stack and infix_to_postfix
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class Stack:
    def __init__(self):
        self.top = None

    def is_empty(self):
        return self.top is None

    def push(self, data):
        new_node = Node(data)
        new_node.next = self.top
        self.top = new_node

    def pop(self):
        if self.is_empty():
            raise IndexError("pop from empty stack")
        data = self.top.data
        self.top = self.top.next
        return data

    def peek(self):
        if self.is_empty():
            return None
        return self.top.data

def is_operator(c):
    return c in {'+', '-', '*', '/'}

def precedence(op):
    if op in {'+', '-'}:
        return 1
    if op in {'*', '/'}:
        return 2
    return 0

def infix_to_postfix(infix_expression):
    stack = Stack()
    postfix = []

    for char in infix_expression.replace(" ", ""):
        if char.isalnum():
            postfix.append(char)
        elif is_operator(char):
            while (not stack.is_empty() and precedence(stack.peek()) >= precedence(char)):
                postfix.append(stack.pop())
            stack.push(char)
        elif char == '(':
            stack.push(char)
        elif char == ')':
            while not stack.is_empty() and stack.peek() != '(':
                postfix.append(stack.pop())
            stack.pop()

    while not stack.is_empty():
        postfix.append(stack.pop())

    return ''.join(postfix)

@app.route("/", methods=["GET", "POST"])
def home():
    result = ""
    if request.method == "POST":
        infix_expression = request.form["infix"]
        try:
            result = infix_to_postfix(infix_expression)
        except Exception as e:
            result = f"Error: {str(e)}"
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
